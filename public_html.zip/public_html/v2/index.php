<!DOCTYPE html>
<html class="desktop mbr-site-loaded"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <!-- Site made with Mobirise AI Website Builder v0.01, https://ai.mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise AI v0.01, ai.mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="https://ai.mobirise.com/assets/startm5/images/logo5.png?v=lq0b9jj6" type="image/x-icon">
  <meta name="description" content="Une association qui recycle des bijoux pour une bonne cause, découvrez comment vous pouvez contribuer!">

  <title>Bijoux Recyclés</title>
  <link rel="stylesheet" href="css/mobirise2.css">
  <link rel="stylesheet" href="css/jarallax.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="css/style_002.css">
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/css2.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@400;700&display=swap"></noscript>
  <link rel="preload" as="style" href="css/additional.css"><link rel="stylesheet" href="css/additional.css" type="text/css">
  
  

  <style>:root{ --background: #FFF6EA; --dominant-color: #FFA62B; --primary-color: #489FB5; --secondary-color: #82C0CC; --success-color: #20AC6B; --danger-color: #AE1E2C; --warning-color: #CC9900; --info-color: #0AA3C2; --background-text: #000000; --dominant-text: #000000; --primary-text: #FFFFFF; --secondary-text: #000000; --success-text: #FFFFFF; --danger-text: #FFFFFF; --warning-text: #000000; --info-text: #FFFFFF;}</style>
<script type="text/javascript" id="www-widgetapi-script" src="js/www-widgetapi.js" async=""></script><script async="" src="iframe_api"></script></head>
<body><section id="top-1" style="display: none;"><a href="https://ai.mobirise.com/" class="animate__animated animate__delay-1s animate__fadeIn">Mobirise AI Website Builder</a> Mobirise AI Alpha v0.01 <a href="https://mobirise.com/builder/ai-website-builder.html" class="animate__animated animate__delay-1s animate__fadeIn">AI Website Builder</a></section>


    <style>
.cid-u6fkJMRQpR  {
  z-index: 1000;
  width: 100%;
  position: relative;
}
.cid-u6fkJMRQpR  .dropdown-item:before {
  font-family: Moririse2 !important;
  content: "\e966";
  display: inline-block;
  width: 0;
  position: absolute;
  left: 1rem;
  top: 0.5rem;
  margin-right: 0.5rem;
  line-height: 1;
  font-size: inherit;
  vertical-align: middle;
  text-align: center;
  overflow: hidden;
  transform: scale(0, 1);
  transition: all 0.25s ease-in-out;
}
@media (max-width: 767px) {
  .cid-u6fkJMRQpR  .navbar-toggler {
    transform: scale(0.8);
  }
}
.cid-u6fkJMRQpR  .navbar-brand {
  flex-shrink: 0;
  align-items: center;
  margin-right: 0;
  padding: 10px 0;
  transition: all 0.3s;
  word-break: break-word;
  z-index: 1;
}
.cid-u6fkJMRQpR  .navbar-brand img {
  max-width: 100%;
  max-height: 100%;
}
.cid-u6fkJMRQpR  .navbar-brand .navbar-caption {
  line-height: inherit !important;
}
.cid-u6fkJMRQpR  .navbar-brand .navbar-logo a {
  outline: none;
}
.cid-u6fkJMRQpR  .navbar-nav {
  margin: auto;
  margin-left: 0;
  margin-left: auto;
}
.cid-u6fkJMRQpR  .navbar-nav .nav-item {
  padding: 0 !important;
  transition: 0.3s all !important;
}
.cid-u6fkJMRQpR  .navbar-nav .nav-item .nav-link {
  padding: 16px !important;
  margin: 0 !important;
  border-radius: 1rem !important;
  transition: 0.3s all !important;
}
.cid-u6fkJMRQpR  .navbar-nav .nav-item .nav-link:hover {
  background-color: rgba(27, 31, 10, 0.06);
}
.cid-u6fkJMRQpR  .navbar-nav .open .nav-link::after {
  transform: rotate(180deg);
}
@media (min-width: 992px) {
  .cid-u6fkJMRQpR  .navbar-nav .open .nav-link::before {
    content: "";
    width: 100%;
    height: 20px;
    top: 100%;
    background: transparent;
    position: absolute;
  }
}
.cid-u6fkJMRQpR  .navbar-nav .dropdown-item {
  padding: 12px !important;
  border-radius: 0.5rem !important;
  margin: 0 8px !important;
  transition: 0.3s all !important;
}
.cid-u6fkJMRQpR  .navbar-nav .dropdown-item:hover {
  background-color: rgba(27, 31, 10, 0.06);
}
@media (min-width: 992px) {
  .cid-u6fkJMRQpR  .navbar-nav {
    padding-left: 1.5rem;
  }
}
.cid-u6fkJMRQpR  .nav-link {
  width: fit-content;
  position: relative;
}
.cid-u6fkJMRQpR  .navbar-logo {
  margin: 0 !important;
}
@media (max-width: 767px) {
  .cid-u6fkJMRQpR  .navbar-logo {
    padding-left: 0;
  }
}
.cid-u6fkJMRQpR  .navbar-caption {
  padding-left: 1rem;
  padding-right: 0.5rem;
}
@media (max-width: 767px) {
  .cid-u6fkJMRQpR  .nav-dropdown {
    padding-bottom: 0.5rem;
  }
}
.cid-u6fkJMRQpR  .nav-dropdown .link.dropdown-toggle::after {
  margin-left: 0.5rem;
  margin-top: 0.2rem;
  transition: 0.3s all;
}
.cid-u6fkJMRQpR  .container {
  display: flex;
  height: 90px;
  padding: 0.5rem 0.6rem;
  flex-wrap: nowrap;
  background: rgba(255, 255, 255, 0.8) !important;
  left: 0;
  right: 0;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: flex-end;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  border-radius: 100vw;
  margin-top: 1rem;
  background-color: #ffffff;
  box-shadow: 0 30px 60px 0 rgba(27, 31, 10, 0.08);
}
@media (max-width: 992px) {
  .cid-u6fkJMRQpR  .container {
    padding-right: 2rem;
  }
}
@media (max-width: 767px) {
  .cid-u6fkJMRQpR  .container {
    width: 95%;
    height: 56px !important;
    padding-right: 1rem;
    margin-top: 0rem;
  }
}
.cid-u6fkJMRQpR  .iconfont-wrapper {
  color: #000000 !important;
  font-size: 1.5rem;
  padding-right: 0.5rem;
}
.cid-u6fkJMRQpR  .dropdown-menu {
  flex-wrap: wrap;
  flex-direction: column;
  max-width: 100%;
  padding: 12px 4px !important;
  border-radius: 1.5rem;
  transition: 0.3s all !important;
  min-width: auto;
  background: #ffffff;
  background: rgba(255, 255, 255, 0.8) !important;
}
.cid-u6fkJMRQpR  .nav-item:focus,
.cid-u6fkJMRQpR  .nav-link:focus {
  outline: none;
}
.cid-u6fkJMRQpR  .dropdown .dropdown-menu .dropdown-item {
  width: auto;
  transition: all 0.25s ease-in-out;
}
.cid-u6fkJMRQpR  .dropdown .dropdown-menu .dropdown-item::after {
  right: 0.5rem;
}
.cid-u6fkJMRQpR  .dropdown .dropdown-menu .dropdown-item .mbr-iconfont {
  margin-right: 0.5rem;
  vertical-align: sub;
}
.cid-u6fkJMRQpR  .dropdown .dropdown-menu .dropdown-item .mbr-iconfont:before {
  display: inline-block;
  transform: scale(1, 1);
  transition: all 0.25s ease-in-out;
}
.cid-u6fkJMRQpR  .collapsed .dropdown-menu .dropdown-item:before {
  display: none;
}
.cid-u6fkJMRQpR  .collapsed .dropdown .dropdown-menu .dropdown-item {
  padding: 0.235em 1.5em 0.235em 1.5em !important;
  transition: none;
  margin: 0 !important;
}
.cid-u6fkJMRQpR  .navbar {
  min-height: 90px;
  transition: all 0.3s;
  border-bottom: 1px solid transparent;
  background: transparent !important;
  padding: 0 !important;
  border: none !important;
  box-shadow: none !important;
  border-radius: 0 !important;
}
.cid-u6fkJMRQpR  .navbar.opened {
  transition: all 0.3s;
}
.cid-u6fkJMRQpR  .navbar .dropdown-item {
  padding: 0.5rem 1.8rem;
}
.cid-u6fkJMRQpR  .navbar .navbar-logo img {
  min-width: 6rem;
  object-fit: cover;
}
.cid-u6fkJMRQpR  .navbar .navbar-collapse {
  z-index: 1;
  justify-content: flex-end;
}
.cid-u6fkJMRQpR  .navbar.collapsed {
  justify-content: center;
}
.cid-u6fkJMRQpR  .navbar.collapsed .nav-item .nav-link::before {
  display: none;
}
.cid-u6fkJMRQpR  .navbar.collapsed.opened .dropdown-menu {
  top: 0;
}
@media (min-width: 992px) {
  .cid-u6fkJMRQpR  .navbar.collapsed.opened:not(.navbar-short) .navbar-collapse {
    max-height: calc(98.5vh - 3rem);
  }
}
.cid-u6fkJMRQpR  .navbar.collapsed .dropdown-menu .dropdown-submenu {
  left: 0 !important;
}
.cid-u6fkJMRQpR  .navbar.collapsed .dropdown-menu .dropdown-item:after {
  right: auto;
}
.cid-u6fkJMRQpR  .navbar.collapsed .dropdown-menu .dropdown-toggle[data-toggle="dropdown-submenu"]:after {
  margin-left: 0.5rem;
  margin-top: 0.2rem;
  border-top: 0.35em solid;
  border-right: 0.35em solid transparent;
  border-left: 0.35em solid transparent;
  border-bottom: 0;
  top: 41%;
}
.cid-u6fkJMRQpR  .navbar.collapsed ul.navbar-nav li {
  margin: auto;
}
.cid-u6fkJMRQpR  .navbar.collapsed .dropdown-menu .dropdown-item {
  padding: 0.25rem 1.5rem;
  text-align: center;
}
.cid-u6fkJMRQpR  .navbar.collapsed .icons-menu {
  padding-left: 0;
  padding-right: 0;
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}
@media (max-width: 767px) {
  .cid-u6fkJMRQpR  .navbar {
    min-height: 72px;
  }
  .cid-u6fkJMRQpR  .navbar .navbar-logo img {
    height: 2.5rem !important;
    min-width: 2.5rem !important;
  }
}
@media (max-width: 991px) {
  .cid-u6fkJMRQpR  .navbar .nav-item .nav-link::before {
    display: none;
  }
  .cid-u6fkJMRQpR  .navbar.opened .dropdown-menu {
    top: 0;
  }
  .cid-u6fkJMRQpR  .navbar .dropdown-menu .dropdown-submenu {
    left: 0 !important;
  }
  .cid-u6fkJMRQpR  .navbar .dropdown-menu .dropdown-item:after {
    right: auto;
  }
  .cid-u6fkJMRQpR  .navbar .dropdown-menu .dropdown-toggle[data-toggle="dropdown-submenu"]:after {
    margin-left: 0.5rem;
    margin-top: 0.2rem;
    border-top: 0.35em solid;
    border-right: 0.35em solid transparent;
    border-left: 0.35em solid transparent;
    border-bottom: 0;
    top: 40%;
  }
  .cid-u6fkJMRQpR  .navbar .dropdown-menu .dropdown-item {
    padding: 0.25rem 1.5rem !important;
    text-align: center;
  }
  .cid-u6fkJMRQpR  .navbar .navbar-brand {
    flex-shrink: initial;
    flex-basis: auto;
    word-break: break-word;
    padding-right: 10px;
  }
  .cid-u6fkJMRQpR  .navbar .navbar-toggler {
    flex-basis: auto;
  }
  .cid-u6fkJMRQpR  .navbar .icons-menu {
    padding-left: 0;
    padding-top: 0.5rem;
    padding-bottom: 0.5rem;
  }
}
.cid-u6fkJMRQpR  .navbar.navbar-short .navbar-logo img {
  height: 2rem;
}
.cid-u6fkJMRQpR  .dropdown-item.active,
.cid-u6fkJMRQpR  .dropdown-item:active {
  background-color: transparent;
}
.cid-u6fkJMRQpR  .navbar-expand-lg .navbar-nav .nav-link {
  padding: 0;
}
.cid-u6fkJMRQpR  .nav-dropdown .link.dropdown-toggle {
  margin-right: 1.667em;
}
.cid-u6fkJMRQpR  .nav-dropdown .link.dropdown-toggle[aria-expanded="true"] {
  margin-right: 0;
  padding: 0.667em 1.667em;
}
.cid-u6fkJMRQpR  .navbar.navbar-expand-lg .dropdown .dropdown-menu {
  background: #ffffff;
}
.cid-u6fkJMRQpR  .navbar.navbar-expand-lg .dropdown .dropdown-menu .dropdown-submenu {
  margin: 0;
  left: 105%;
  transform: none;
  top: -12px;
}
.cid-u6fkJMRQpR  .navbar .dropdown.open > .dropdown-menu {
  display: flex;
}
.cid-u6fkJMRQpR  ul.navbar-nav {
  flex-wrap: wrap;
}
.cid-u6fkJMRQpR  .navbar-buttons {
  text-align: center;
  min-width: 140px;
}
@media (max-width: 992px) {
  .cid-u6fkJMRQpR  .navbar-buttons {
    text-align: left;
  }
}
.cid-u6fkJMRQpR  button.navbar-toggler {
  outline: none;
  width: 31px;
  height: 20px;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
  align-self: center;
}
.cid-u6fkJMRQpR  button.navbar-toggler .hamburger span {
  position: absolute;
  right: 0;
  width: 30px;
  height: 2px;
  border-right: 5px;
  background-color: #000000;
}
.cid-u6fkJMRQpR  button.navbar-toggler .hamburger span:nth-child(1) {
  top: 0;
  transition: all 0.2s;
}
.cid-u6fkJMRQpR  button.navbar-toggler .hamburger span:nth-child(2) {
  top: 8px;
  transition: all 0.15s;
}
.cid-u6fkJMRQpR  button.navbar-toggler .hamburger span:nth-child(3) {
  top: 8px;
  transition: all 0.15s;
}
.cid-u6fkJMRQpR  button.navbar-toggler .hamburger span:nth-child(4) {
  top: 16px;
  transition: all 0.2s;
}
.cid-u6fkJMRQpR  nav.opened .hamburger span:nth-child(1) {
  top: 8px;
  width: 0;
  opacity: 0;
  right: 50%;
  transition: all 0.2s;
}
.cid-u6fkJMRQpR  nav.opened .hamburger span:nth-child(2) {
  transform: rotate(45deg);
  transition: all 0.25s;
}
.cid-u6fkJMRQpR  nav.opened .hamburger span:nth-child(3) {
  transform: rotate(-45deg);
  transition: all 0.25s;
}
.cid-u6fkJMRQpR  nav.opened .hamburger span:nth-child(4) {
  top: 8px;
  width: 0;
  opacity: 0;
  right: 50%;
  transition: all 0.2s;
}
.cid-u6fkJMRQpR  .navbar-dropdown {
  padding: 0 1rem;
}
.cid-u6fkJMRQpR  a.nav-link {
  display: flex;
  align-items: center;
  justify-content: center;
}
.cid-u6fkJMRQpR  .icons-menu {
  flex-wrap: nowrap;
  display: flex;
  justify-content: center;
  padding-left: 1rem;
  padding-right: 1rem;
  padding-top: 0.3rem;
  text-align: center;
}
@media (max-width: 992px) {
  .cid-u6fkJMRQpR  .icons-menu {
    justify-content: flex-start;
    margin-bottom: 0.5rem;
  }
}
@media screen and (-ms-high-contrast: active), (-ms-high-contrast: none) {
  .cid-u6fkJMRQpR  .navbar {
    height: 70px;
  }
  .cid-u6fkJMRQpR  .navbar.opened {
    height: auto;
  }
  .cid-u6fkJMRQpR  .nav-item .nav-link:hover::before {
    width: 175%;
    max-width: calc(100% + 2rem);
    left: -1rem;
  }
}
.cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu {
  display: none;
  width: max-content;
  max-width: 500px !important;
  transform: translateX(-50%);
  top: calc(100% + 20px);
  left: 50%;
}
.cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu .dropdown-item {
  line-height: 1 !important;
}
.cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu .dropdown .dropdown-item {
  align-items: center;
  display: flex;
  height: max-content !important;
  min-height: max-content !important;
}
.cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu .dropdown .dropdown-item::after {
  display: inline-block;
  position: static;
  margin-left: 0.5rem;
  margin-top: 0;
  margin-right: 0;
  margin-bottom: 0;
  transition: 0.3s all;
  transform: rotate(-90deg);
}
.cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu .dropdown.open .dropdown-item::after {
  transform: rotate(0deg);
}
.cid-u6fkJMRQpR  .mbr-section-btn {
  margin: -0.6rem -0.6rem;
}
.cid-u6fkJMRQpR  .navbar-toggler {
  margin-left: 12px;
  margin-right: 8px;
  order: 1000;
}
@media (max-width: 991px) {
  .cid-u6fkJMRQpR  .navbar-brand {
    margin-right: auto;
  }
  .cid-u6fkJMRQpR  .navbar-collapse {
    z-index: -1 !important;
    position: absolute;
    top: 110%;
    left: 0;
    width: 100%;
    padding: 1rem;
    border-radius: 1.5rem;
    background: #ffffff;
    opacity: 1;
    border-color: rgba(255, 255, 255, 0.8) !important;
    background: rgba(255, 255, 255, 0.8) !important;
    backdrop-filter: blur(8px);
  }
  .cid-u6fkJMRQpR  .navbar-nav .nav-item .nav-link::after {
    margin-left: 10px;
  }
  .cid-u6fkJMRQpR  .navbar-nav .dropdown-item:hover {
    background-color: rgba(27, 31, 10, 0.06);
  }
  .cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu {
    max-width: 100% !important;
    transform: translateX(0);
    top: 10px;
    left: 0;
    padding: 8px !important;
    border-radius: 1rem;
    background-color: rgba(27, 31, 10, 0.04) !important;
  }
  .cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu .dropdown-item {
    padding: 8px !important;
    line-height: 1 !important;
    margin-bottom: 4px !important;
  }
  .cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu .dropdown .dropdown-item {
    align-items: center;
    display: flex;
    height: max-content !important;
    min-height: max-content !important;
  }
  .cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu .dropdown .dropdown-item::after {
    display: inline-block;
    position: static;
    margin-left: 0.5rem;
    margin-top: 0;
    margin-right: 0;
    margin-bottom: 0;
    transition: 0.3s all;
    transform: rotate(0deg);
  }
  .cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu .dropdown.open .dropdown-item::after {
    transform: rotate(180deg);
  }
  .cid-u6fkJMRQpR  .navbar .dropdown > .dropdown-menu .dropdown-submenu {
    position: static;
    width: 100%;
    max-width: 100% !important;
    transform: translateX(0) !important;
    top: 0;
    left: 0;
    padding: 8px !important;
    border-radius: 1rem;
    background-color: rgba(27, 31, 10, 0.04) !important;
  }
  .cid-u6fkJMRQpR  .navbar .dropdown.open > .dropdown-menu {
    display: flex !important;
    flex-direction: column;
    align-items: flex-start;
  }
}
@media (max-width: 575px) {
  .cid-u6fkJMRQpR  .navbar-collapse {
    padding: 1rem;
  }
}
</style>

<?php
$mysqli = new mysqli('localhost','e22110817sql','GqEMe!!p','e22110817_db1');
if ($mysqli->connect_errno)
{
 // Affichage d'un message d'erreur
 echo "Error: Problème de connexion à la BDD \n";
 echo "Errno: " . $mysqli->connect_errno . "\n";
 echo "Error: " . $mysqli->connect_error . "\n";
 // Arrêt du chargement de la page
 exit();
}
// Instructions PHP à ajouter pour l'encodage utf8 du jeu de caractères
if (!$mysqli->set_charset("utf8")) {
 printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
 exit();
}
echo ("Connexion BDD réussie !");
?>
<?php
//...
//echo ("Connexion BDD réussie !");
//On insère une ligne dans la table gérant les comptes des utilisateurs
//$requete2="INSERT INTO t_compte_cpt VALUES ('tux',MD5('tux1234'));";
//echo ($requete2);
//$result2 = $mysqli->query($requete2); //Exécution de la requête
//if ($result2 == false) //Erreur d’exécution de la requête
//{ // La requête a echoué
// echo "Error: La requête a echoué \n";
// echo "Errno: " . $mysqli->errno . "\n";
// echo "Error: " . $mysqli->error . "\n";
// exit();
//}
//else //Exécution de la requête réussie
//{
//echo "<br />";
//echo "Insertion réussie" . "\n";
//echo "<br />";
//}
////Ferme la connexion avec la base MariaDB
//$mysqli->close();
?>
<section class="menu menu2 cid-u6fkJMRQpR" once="menu" id="menu-5-u6fkJMRQpR">
  <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg opacityScroll">
    <div class="container">
      <div class="navbar-brand">
        <span class="navbar-logo">
					<a href="https://mobiri.se/">
						<img src="images/index_014.jpeg" style="height: 4.3rem;">
					</a>
				</span>
				<span class="navbar-caption-wrap">
          <a class="navbar-caption text-black display-4" href="https://mobiri.se/">BijouRecycle</a>
        </span>
      </div>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse" data-target="#navbarSupportedContent" data-bs-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <div class="hamburger">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
        </div>
      </button>
      <div class="collapse navbar-collapse opacityScroll" id="navbarSupportedContent">
        <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true">
          <li class="nav-item">
            <a class="nav-link link text-black display-4" href="">Accueil</a>
          </li>
          <li class="nav-item">
            <a class="nav-link link text-black display-4" href="./recapitulatif/recapitulatif.php" aria-expanded="false">Recapitulatif</a>
          </li>
          <li class="nav-item">
            <a class="nav-link link text-black display-4" href="./inscription/inscription.php">Inscription</a>
          </li>
          <li class="nav-item">
            <a class="nav-link link text-black display-4" href="./recapitulatif/session.php">Admin</a>
          </li>
        </ul>
        <div class="navbar-buttons mbr-section-btn">
          <a class="btn btn-primary display-4" href="https://mobiri.se/">Découvrir</a>
        </div>
      </div>
    </div>
  </nav>
</section>
<?php
// Requête pour obtenir le nombre de sujets et de fiches actifs
$requete_bis = "SELECT COUNT(DISTINCT suj_numero) AS nb_sujets, COUNT(*) AS nb_fiches FROM t_sujet_suj LEFT JOIN t_fichier_fic USING (suj_numero) ";
$result1_bis = $mysqli->query($requete_bis);
$nb = $result1_bis->fetch_assoc();
if ($result1_bis == false) //Erreur lors de l’exécution de la requête
{ // La requête a echoué
 echo "Error: La requête a echoué \n";
 echo "Errno: " . $mysqli->errno . "\n";
 echo "Error: " . $mysqli->error . "\n";
 exit();
}
else
// Affichage du nombre de sujets et de fiches actifs
//echo "<p>Nombre de sujets actifs : {$nb['nb_sujets']}</p>";
//echo "<p>Nombre de fiches actives : {$nb['nb_fiches']}</p>";

?>

<section class="features16 cid-u6fkJMTnLd" id="features-32-u6fkJMTnLd">
    <div class="container">
        <div class="row justify-content-center">
            <div class="item features-without-image col-12 col-lg-4 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="card-box">
                        <div class="img-box">
                            <div class="image-wrapper mb-3">
                                <img src="images/index_023.jpeg">
                            </div>
                        </div>
                        <h4 class="card-title mbr-fonts-style mb-0 display-7">
                            <strong><?php echo "<p>Nombre de sujets actifs : </p>";?></strong>
                        </h4>
                        <h5 class="card-text mbr-fonts-style mt-2 display-7">
                        <?php echo "<p> {$nb['nb_sujets']}</p>";?>
                        </h5>
                    </div>
                </div>
            </div>
            <div class="item features-without-image col-12 col-lg-4 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="card-box"> 
                        <div class="img-box">
                            <div class="image-wrapper mb-3">
                                <img src="images/index_019.jpeg">
                            </div>
                        </div>
                        <h4 class="card-title mbr-fonts-style mb-0 display-7">
                            <strong><?php echo "<p>Nombre de fiches actives :</p>";?></strong>
                        </h4>
                        <h5 class="card-text mbr-fonts-style mt-2 display-7">
                        <?php echo "<p>{$nb['nb_fiches']}</p>";?>
                        </h5>
                    </div>
                </div>
            </div>
            
            </div>
        </div>
    </div>
</section>
<?php

// Requête pour obtenir les 10 actualités les plus récentes
$requete="SELECT * FROM t_news_new ORDER BY new_date DESC LIMIT 10;";
//Affichage de la requête préparée
echo ($requete);
$result1 = $mysqli->query($requete);
if ($result1 == false) //Erreur lors de l’exécution de la requête
{ // La requête a echoué
 echo "Error: La requête a echoué \n";
 echo "Errno: " . $mysqli->errno . "\n";
 echo "Error: " . $mysqli->error . "\n";
 exit();
}
else //La requête s’est bien exécutée (<=> couleur verte dans phpmyadmin)
{
echo "<br />";
echo($result1->num_rows); //Donne le bon nombre de lignes récupérées
 echo "<br />";
// Affichage du tableau d'actualités
echo '<table class ="table">';
echo '<tr><th>Titre</th><th>Date de publication</th><th>Contenu</th><th>Auteur</th></tr>';
  while ($actu = $result1->fetch_assoc()) {
    echo '<tr>';
    echo '<td>' . $actu['new_titre'] . '</td>';
    echo '<td>' . $actu['new_date'] . '</td>';
    echo '<td>' . $actu['new_texte'] . '</td>';
    echo '<td>' . $actu['cpt_pseudo'] . '</td>';
    echo '</tr>';
}
echo '</table>';
}
//Ferme la connexion avec la base MariaDB
$mysqli->close();
?>
    <style>
  .cid-u6fkJMS37O {
    display: flex;
    background-image: url("https://proxy.electricblaze.com/?u=https%3A%2F%2Fimages.unsplash.com%2Fphoto-1502652023201-a16bde8138d2%3Fixid%3DM3w0Mzc5fDB8MXxzZWFyY2h8MzB8fGpld2VscnklMjByZWN5Y2xlZHxlbnwwfDB8fHwxNzA2ODc0ODg1fDA%26ixlib%3Drb-4.0.3%26auto%3Dformat%26fit%3Dcrop%26w%3D1200%26q%3D80&e=1709795253&s=sAC9KVOW2BdBKx6r7EhNasAHlwlqASGDA8Q7Z8WzXM4");
  }
  .cid-u6fkJMS37O .mbr-overlay {
    background-color: #000000;
    opacity: 0.5;
  }
  @media (min-width: 768px) {
    .cid-u6fkJMS37O {
      align-items: flex-end;
    }
    .cid-u6fkJMS37O .row {
      justify-content: center;
    }
    .cid-u6fkJMS37O .content-wrap {
      padding: 1rem 3rem;
    }
  }
  @media (max-width: 991px) and (min-width: 768px) {
    .cid-u6fkJMS37O .content-wrap {
      min-width: 50%;
    }
  }
  @media (max-width: 767px) {
    .cid-u6fkJMS37O {
      -webkit-align-items: center;
      align-items: flex-end;
    }
    .cid-u6fkJMS37O .mbr-row {
      -webkit-justify-content: center;
      justify-content: center;
    }
    .cid-u6fkJMS37O .content-wrap {
      width: 100%;
    }
  }
  .cid-u6fkJMS37O .mbr-section-title,
  .cid-u6fkJMS37O .mbr-section-subtitle {
    text-align: center;
  }
  .cid-u6fkJMS37O .mbr-text,
  .cid-u6fkJMS37O .mbr-section-btn {
    text-align: center;
  }
</style>
<section class="header16 cid-u6fkJMS37O mbr-fullscreen mbr-parallax-background" id="hero-17-u6fkJMS37O" style="z-index: 0; background-image: none; position: relative;">
  <div class="mbr-overlay" style="opacity: 0.3; background-color: rgb(0, 0, 0);"></div>
  <div class="container-fluid">
    <div class="row">
      <div class="content-wrap col-12 col-md-10">
        <h1 class="mbr-section-title mbr-fonts-style mbr-white mb-4 display-1 animate__animated animate__delay-1s animate__fadeIn">
          <strong>Bijoux Écologiques</strong>
        </h1>
        <p class="mbr-fonts-style mbr-text mbr-white mb-4 display-7 animate__animated animate__delay-1s animate__fadeIn">Découvrez notre collection de bijoux recyclés et soutenez notre mission de bienfaisance.</p>
        <div class="mbr-section-btn"><a class="btn btn-white-outline display-7 animate__animated animate__delay-1s animate__fadeIn" href="#">Explorer</a></div>
      </div>
    </div>
  </div>
<div style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; overflow: hidden; z-index: -100;" id="jarallax-container-0"><div style="background-position: 50% 50%; background-size: cover; background-repeat: no-repeat; background-image: url(&quot;https://proxy.electricblaze.com/?u=https%3A%2F%2Fimages.unsplash.com%2Fphoto-1502652023201-a16bde8138d2%3Fixid%3DM3w0Mzc5fDB8MXxzZWFyY2h8MzB8fGpld2VscnklMjByZWN5Y2xlZHxlbnwwfDB8fHwxNzA2ODc0ODg1fDA%26ixlib%3Drb-4.0.3%26auto%3Dformat%26fit%3Dcrop%26w%3D1200%26q%3D80&amp;e=1709795253&amp;s=sAC9KVOW2BdBKx6r7EhNasAHlwlqASGDA8Q7Z8WzXM4&quot;); position: absolute; top: 0px; left: 0px; width: 1920px; height: 944px; overflow: hidden; pointer-events: none; transform-style: preserve-3d; backface-visibility: hidden; will-change: transform, opacity; margin-top: 0px; transform: translate3d(0px, 0px, 0px);"></div></div></section>
    <style>
  .cid-u6fkJMSOf4 {
    padding-top: 5rem;
    padding-bottom: 5rem;
    background-color: #ffffff;
  }
  .cid-u6fkJMSOf4 .item-subtitle {
    line-height: 1.2;
    color: #000000;
  }
  .cid-u6fkJMSOf4 img,
  .cid-u6fkJMSOf4 .item-img {
    width: 100%;
  }
  .cid-u6fkJMSOf4 .item:focus,
  .cid-u6fkJMSOf4 span:focus {
    outline: none;
  }
  .cid-u6fkJMSOf4 .item {
    margin-bottom: 2rem;
  }
  @media (max-width: 575px) {
    .cid-u6fkJMSOf4 .item {
      margin-bottom: 1rem;
    }
  }
  .cid-u6fkJMSOf4 .item-wrapper {
    position: relative;
    border-radius: 4px;
    height: 100%;
    display: flex;
    flex-flow: column nowrap;
  }
  .cid-u6fkJMSOf4 .mbr-section-title {
    color: #000000;
  }
  .cid-u6fkJMSOf4 .mbr-text,
  .cid-u6fkJMSOf4 .mbr-section-btn {
    color: #000000;
  }
  .cid-u6fkJMSOf4 .item-title {
    color: #000000;
    text-align: center;
  }
  .cid-u6fkJMSOf4 .content-head {
    max-width: 800px;
  }
  .cid-u6fkJMSOf4 img {
    filter: grayscale(1);
  }
</style>
<section class="features03 cid-u6fkJMSOf4" id="partners-1-u6fkJMSOf4">
    <div class="container-fluid">
        <div class="row justify-content-center mb-5">
            <div class="col-12 content-head">
                <div class="mbr-section-head">
                    <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2 hidden animate__animated animate__delay-1s">
                        <strong>Nos Partenaires</strong>
                    </h4>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="item features-image col-12 col-md-6 col-sm-6 col-lg-2 active hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_031.jpeg" data-slide-to="1" data-bs-slide-to="1">
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-sm-6 col-lg-2 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_012.jpeg" data-slide-to="2" data-bs-slide-to="2">
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-sm-6 col-lg-2 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_010.jpeg" data-slide-to="3" data-bs-slide-to="3">
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-sm-6 col-lg-2 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_011.jpeg" data-slide-to="4" data-bs-slide-to="4">
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-sm-6 col-lg-2 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_039.jpeg" data-slide-to="5" data-bs-slide-to="5">
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-sm-6 col-lg-2 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_028.jpeg" data-slide-to="6" data-bs-slide-to="6">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    <style>
.cid-u6fkJMSz5P {
  overflow: hidden;
  background-image: url("https://proxy.electricblaze.com/?u=https%3A%2F%2Fimages.unsplash.com%2Fphoto-1646729470975-6dc8a46deca2%3Fixid%3DM3w0Mzc5fDB8MXxzZWFyY2h8OHx8amV3ZWxyeSUyMHJlY3ljbGVkfGVufDB8MHx8fDE3MDY4NzQ4ODV8MA%26ixlib%3Drb-4.0.3%26auto%3Dformat%26fit%3Dcrop%26w%3D1200%26q%3D80&e=1709795253&s=R-KC8C-xqL-e42mdRX-x6imO49Mkw061bCawutT9DkM");
}
</style>
<section class="image02 cid-u6fkJMSz5P mbr-fullscreen mbr-parallax-background" id="image-13-u6fkJMSz5P" style="z-index: 0; background-image: none; position: relative;">
    <div class="container">
        <div class="row"></div>
    </div>
<div style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; overflow: hidden; z-index: -100;" id="jarallax-container-1"><div style="background-position: 50% 50%; background-size: cover; background-repeat: no-repeat; background-image: url(&quot;https://proxy.electricblaze.com/?u=https%3A%2F%2Fimages.unsplash.com%2Fphoto-1646729470975-6dc8a46deca2%3Fixid%3DM3w0Mzc5fDB8MXxzZWFyY2h8OHx8amV3ZWxyeSUyMHJlY3ljbGVkfGVufDB8MHx8fDE3MDY4NzQ4ODV8MA%26ixlib%3Drb-4.0.3%26auto%3Dformat%26fit%3Dcrop%26w%3D1200%26q%3D80&amp;e=1709795253&amp;s=R-KC8C-xqL-e42mdRX-x6imO49Mkw061bCawutT9DkM&quot;); position: absolute; top: 0px; left: 0px; width: 1920px; height: 944px; overflow: hidden; pointer-events: none; transform-style: preserve-3d; backface-visibility: hidden; will-change: transform, opacity; margin-top: 0px; transform: translate3d(0px, -577.14px, 0px);"></div></div></section>
    <style>
.cid-u6fkJMSzHu .mbr-fallback-image.disabled {
  display: none;
}
.cid-u6fkJMSzHu .mbr-fallback-image {
  display: block;
  background-size: cover;
  background-position: center center;
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  background: #000000;
}
</style>
<section class="header18 cid-u6fkJMSzHu mbr-fullscreen" data-bg-video="https://www.youtube.com/embed/afw4UrXqcu8?autoplay=1&amp;loop=1&amp;playlist=afw4UrXqcu8&amp;t=20&amp;mute=1&amp;playsinline=1&amp;controls=0&amp;showinfo=0&amp;autohide=1&amp;allowfullscreen=true&amp;mode=transparent" id="video-5-u6fkJMSzHu"><div class="mbr-background-video-preview" style="display: block; background-size: cover; background-position: center center; background-image: url(&quot;https://img.youtube.com/vi/afw4UrXqcu8/sddefault.jpg&quot;);"></div><div style="overflow: hidden; position: absolute; width: 100%; height: 100%; top: 0px; left: 0px;"><div style="background: rgb(0, 0, 0) none repeat scroll 0% 0%; inset: 0px;"><div class="mbr-video-foreground" style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; pointer-events: none; overflow: hidden;"><iframe class="mbr-background-video" id="ytplayer-b9328b" style="margin-top: 0px; max-width: initial; transition-property: opacity; transition-duration: 1000ms; pointer-events: none; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; transform: scale(1.2);" allowfullscreen="" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" title="How to string recycled Jewelry Design" src="afw4UrXqcu8.html" width="1920" height="1080" frameborder="0"></iframe></div></div></div><div style="overflow: hidden; position: absolute; width: 100%; height: 100%; top: 0px; left: 0px;"><div style="background: rgb(0, 0, 0) none repeat scroll 0% 0%; inset: 0px;"><div class="mbr-video-foreground" style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; pointer-events: none; overflow: hidden;"></div></div></div>
  <div class="mbr-overlay" style="opacity: 0.3; background-color: rgb(0, 0, 0);"></div>
  <div class="container-fluid">
    <div class="row">
    </div>
  </div>
</section>
    <style>
  .cid-u6fkJMSAJ6 {
    padding-top: 5rem;
    padding-bottom: 5rem;
    background-color: transparent;
  }
  .cid-u6fkJMSAJ6 .mbr-fallback-image.disabled {
    display: none;
  }
  .cid-u6fkJMSAJ6 .mbr-fallback-image {
    display: block;
    background-size: cover;
    background-position: center center;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
  }
  @media (max-width: 767px) {
    .cid-u6fkJMSAJ6 .card-content-text {
      padding: 0 1.5rem 1.5rem 1.5rem;
    }
  }
  @media (min-width: 768px) {
    .cid-u6fkJMSAJ6 .card-content-text {
      padding: 0 2.25rem 2.25rem 2.25rem;
    }
  }
  @media (min-width: 992px) {
    .cid-u6fkJMSAJ6 .card-content-text {
      padding: 1rem 4rem 4rem 4rem;
    }
  }
  .cid-u6fkJMSAJ6 .card-wrapper {
    background: #ffffff;
  }
  .cid-u6fkJMSAJ6 .mbr-text,
  .cid-u6fkJMSAJ6 .mbr-section-btn {
    color: #000000;
    text-align: left;
  }
  .cid-u6fkJMSAJ6 .card-title,
  .cid-u6fkJMSAJ6 .card-box {
    text-align: left;
    color: #000000;
  }
</style>
<section class="article8 cid-u6fkJMSAJ6" id="about-us-8-u6fkJMSAJ6">
  <div class="container">
    <div class="row justify-content-center">
      <div class="card col-md-12 col-lg-10">
        <div class="card-wrapper">
          <div class="image-wrapper d-flex justify-content-center mb-4">
            <img src="images/index_038.jpeg" class="hidden animate__animated animate__delay-1s">
          </div>
          <div class="card-content-text">
            <h3 class="card-title mbr-fonts-style mbr-white mt-3 mb-4 display-2 hidden animate__animated animate__delay-1s">
            <strong>Notre Histoire</strong>
          </h3>
          <div class="row card-box align-left">
            <div class="item features-without-image col-12 hidden animate__animated animate__delay-1s">
              <div class="item-wrapper">
                <p class="mbr-text mbr-fonts-style display-7">Chez 
BijouRecycle, nous croyons en la beauté de la durabilité. Chaque bijou 
que nous vendons est fabriqué à partir de matériaux recyclés, et une 
partie des bénéfices est reversée à des associations caritatives.</p>
              </div>
            </div>
            <div class="item features-without-image col-12 hidden animate__animated animate__delay-1s">
              <div class="item-wrapper">
                <p class="mbr-text mbr-fonts-style display-7">Depuis 
notre création, nous avons eu un impact positif sur la communauté en 
soutenant des causes telles que l'éducation, la santé et 
l'environnement.</p>
              </div>
            </div>
            <div class="item features-without-image col-12 hidden animate__animated animate__delay-1s">
              <div class="item-wrapper">
                <p class="mbr-text mbr-fonts-style display-7">Rejoignez-nous dans notre mission de créer un monde plus beau et plus durable grâce à la magie des bijoux recyclés.</p>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
    <style>
    .cid-u6fkJMShrd {
        padding-top: 5rem;
        padding-bottom: 5rem;
        background-color: transparent;
    }

    .cid-u6fkJMShrd img,
    .cid-u6fkJMShrd .item-img {
        width: 100%;
        height: 100%;
        height: 400px;
        object-fit: cover;
    }

    .cid-u6fkJMShrd .item:focus,
    .cid-u6fkJMShrd span:focus {
        outline: none;
    }

    .cid-u6fkJMShrd .item {
        margin-bottom: 2rem;
    }

    @media (max-width: 767px) {
        .cid-u6fkJMShrd .item {
            margin-bottom: 1rem;
        }
    }

    .cid-u6fkJMShrd .item-content {
        margin-top: 2rem;
        padding: 0 2.25rem 2.25rem;
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    @media (min-width: 992px) and (max-width: 1200px) {
        .cid-u6fkJMShrd .item-content {
            padding: 2rem 1.5rem;
            padding-top: 1rem;
            margin-top: 1rem;
        }
    }

    @media (max-width: 767px) {
        .cid-u6fkJMShrd .item-content {
            padding: 2rem 1.5rem;
            padding-top: 1rem;
            margin-top: 1rem;
        }
    }

    .cid-u6fkJMShrd .item-wrapper {
        position: relative;
        background: #ffffff;
        height: 100%;
        display: flex;
        flex-flow: column nowrap;
    }

    .cid-u6fkJMShrd .item-wrapper .item-footer {
        margin-top: auto;
    }

    .cid-u6fkJMShrd .mbr-section-title {
        color: #000000;
    }

    .cid-u6fkJMShrd .item-title {
        text-align: left;
    }

    .cid-u6fkJMShrd .item-subtitle {
        text-align: left;
    }

    .cid-u6fkJMShrd .mbr-text,
    .cid-u6fkJMShrd .item .mbr-section-btn {
        text-align: left;
    }

    .cid-u6fkJMShrd .content-head {
        max-width: 800px;
    }
</style>
<section class="pricing02 cid-u6fkJMShrd" id="product-list-9-u6fkJMShrd">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12 content-head">
                <div class="mbr-section-head mb-5">
                    <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2 hidden animate__animated animate__delay-1s">
                        <strong>Bijoux Recyclés</strong>
                    </h4>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="item features-image col-12 col-md-6 col-lg-4 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_032.jpeg">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-5">
                            <strong>Bague Écologique</strong>
                        </h5>
                        <h6 class="item-subtitle mbr-fonts-style display-7">
                            25€
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Une bague unique fabriquée à partir de matériaux recyclés, parfaite pour les amoureux de la nature.
                        </p>
                        <div class="mbr-section-btn item-footer"><a href="" class="btn item-btn btn-primary display-7">Acheter maintenant</a></div>
                    </div>

                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-lg-4 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_030.jpeg">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-5">
                            <strong>Collier Éthique</strong>
                        </h5>
                        <h6 class="item-subtitle mbr-fonts-style display-7">
                            35€
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Un collier élégant conçu à partir de matériaux recyclés, idéal pour un look écologique et tendance.
                        </p>
                        <div class="mbr-section-btn item-footer"><a href="" class="btn item-btn btn-primary display-7">Acheter maintenant</a></div>
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-lg-4 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_009.jpeg" alt="">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-5">
                            <strong>Boucles d'Oreilles Durables</strong>
                        </h5>
                        <h6 class="item-subtitle mbr-fonts-style display-7">
                            20€
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Des boucles d'oreilles légères et durables, 
fabriquées à partir de matériaux recyclés, pour un style éco-chic.<br>
                        </p>
                        <div class="mbr-section-btn item-footer"><a href="" class="btn item-btn btn-primary display-7">Acheter maintenant</a></div>
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-lg-4 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_004.jpeg">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-5">
                            <strong>Bracelet Respectueux de l'Environnement</strong>
                        </h5>
                        <h6 class="item-subtitle mbr-fonts-style display-7">
                            30€
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Un bracelet coloré et respectueux de 
l'environnement, conçu à partir de matériaux recyclés, pour un look 
éthique et moderne.<br>
                        </p>
                        <div class="mbr-section-btn item-footer"><a href="" class="btn item-btn btn-primary display-7">Acheter maintenant</a></div>
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-lg-4 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_024.jpeg">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-5">
                            <strong>Pendentif Éco-Friendly</strong>
                        </h5>
                        <h6 class="item-subtitle mbr-fonts-style display-7">
                            40€
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Un pendentif élégant et éco-friendly, 
fabriqué à partir de matériaux recyclés, pour un style responsable et 
sophistiqué.<br>
                        </p>
                        <div class="mbr-section-btn item-footer"><a href="" class="btn item-btn btn-primary display-7">Acheter maintenant</a></div>
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-lg-4 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img">
                        <img src="images/index_021.jpeg">
                    </div>
                    <div class="item-content">
                        <h5 class="item-title mbr-fonts-style display-5">
                            <strong>Montre Éco-Consciente</strong>
                        </h5>
                        <h6 class="item-subtitle mbr-fonts-style display-7">
                            50€
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Une montre élégante et éco-consciente, 
fabriquée à partir de matériaux recyclés, pour un look moderne et 
respectueux de l'environnement.<br>
                        </p>
                        <div class="mbr-section-btn item-footer"><a href="" class="btn item-btn btn-primary display-7">Acheter maintenant</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    <style>
  .cid-u6fkJMSY0I {
    padding-top: 5rem;
    padding-bottom: 5rem;
    background-color: transparent;
  }
  .cid-u6fkJMSY0I .mbr-fallback-image.disabled {
    display: none;
  }
  .cid-u6fkJMSY0I .mbr-fallback-image {
    display: block;
    background-size: cover;
    background-position: center center;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
  }
  .cid-u6fkJMSY0I .card-wrapper {
    background: var(--dominant-color, #393193);
    border-radius: 4px;
  }
  @media (max-width: 767px) {
    .cid-u6fkJMSY0I .card-wrapper {
      padding: 1.5rem;
    }
  }
  @media (min-width: 768px) and (max-width: 991px) {
    .cid-u6fkJMSY0I .card-wrapper {
      padding: 2.25rem;
    }
  }
  @media (min-width: 992px) {
    .cid-u6fkJMSY0I .card-wrapper {
      padding: 4rem;
    }
  }
  .cid-u6fkJMSY0I .mbr-text,
  .cid-u6fkJMSY0I .mbr-section-btn {
    color: #ffd7ef;
  }
  .cid-u6fkJMSY0I .card-title,
  .cid-u6fkJMSY0I .card-box {
    text-align: center;
    color: var(--dominant-text, #ffd7ef);
  }
</style>
<section class="article13 cid-u6fkJMSY0I" id="call-to-action-3-u6fkJMSY0I">
    <div class="container">
        <div class="row justify-content-center">
            <div class="card col-md-12 col-lg-10">
                <div class="card-wrapper">
                    <div class="card-box align-left">
                        <h4 class="card-title mbr-fonts-style display-2 hidden animate__animated animate__delay-1s">
                            <strong>Rejoignez la Révolution Écologique</strong>
                        </h4>
                        <div class="mbr-section-btn mt-4">
                        <a class="btn btn-primary display-4 hidden animate__animated animate__delay-1s" href="https://mobiri.se/">Découvrir</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    <style>
    .cid-u6fkJMTnLd {
        padding-top: 5rem;
        padding-bottom: 3rem;
        background-color: #ffffff;
    }

    .cid-u6fkJMTnLd .mbr-fallback-image.disabled {
        display: none;
    }

    .cid-u6fkJMTnLd .mbr-fallback-image {
        display: block;
        background-size: cover;
        background-position: center center;
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
    }

    .cid-u6fkJMTnLd .item-wrapper {
        display: flex;
        margin-bottom: 2rem;
    }

    @media (max-width: 767px) {
        .cid-u6fkJMTnLd .item-wrapper {
            margin-bottom: 2rem;
        }
    }

    .cid-u6fkJMTnLd .mbr-section-title {
        text-align: center;
    }

    .cid-u6fkJMTnLd .mbr-section-subtitle {
        text-align: center;
    }

    .cid-u6fkJMTnLd .image-wrapper {
        width: 5rem;
        height: 5rem;
        border-radius: 50%;
        overflow: hidden;
    }

    .cid-u6fkJMTnLd .image-wrapper img {
        height: 100%;
        width: 100%;
        object-fit: cover;
    }

    .cid-u6fkJMTnLd .content-head {
        max-width: 800px;
    }

    .cid-u6fkJMTnLd .img-box {
        display: flex;
        justify-content: center;
    }

    .cid-u6fkJMTnLd .card-title {
        text-align: center;
    }

    .cid-u6fkJMTnLd .card-text {
        text-align: center;
    }

    .cid-u6fkJMTnLd .link {
        text-align: center;
    }
</style>

<style>
.cid-u6fkJMTnph {
  padding-top: 6rem;
  padding-bottom: 6rem;
  background-color: transparent;
}
.cid-u6fkJMTnph .item-wrapper img {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: 50% !important;
}
.cid-u6fkJMTnph .item-wrapper {
  background: #ffffff;
  margin-bottom: 2rem;
  padding: 2.25rem;
}
@media (min-width: 992px) and (max-width: 1200px) {
  .cid-u6fkJMTnph .item-wrapper {
    padding: 1.5rem;
    margin-bottom: 2rem;
  }
}
@media (max-width: 767px) {
  .cid-u6fkJMTnph .item-wrapper {
    padding: 1.5rem;
    margin-bottom: 1rem;
  }
}
.cid-u6fkJMTnph .card-title,
.cid-u6fkJMTnph .iconfont-wrapper {
  color: #000000;
}
.cid-u6fkJMTnph .card-text {
  color: #000000;
  text-align: left;
}
.cid-u6fkJMTnph .content-head {
  max-width: 800px;
}
.cid-u6fkJMTnph .mbr-section-title {
  color: #000000;
}
.cid-u6fkJMTnph .card-title,
.cid-u6fkJMTnph .img-wrapper {
  text-align: center;
}
.cid-u6fkJMTnph .img-wrapper {
  display: flex;
  justify-content: center;
}
</style>
<section class="people04 cid-u6fkJMTnph" id="testimonials-4-u6fkJMTnph">
	<div class="container">
		<div class="row mb-5 justify-content-center">
			<div class="col-12 mb-0 content-head">
				<h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2 hidden animate__animated animate__delay-1s">
					<strong>Témoignages</strong>
				</h3>	
			</div>
		</div>
		<div class="row mbr-masonry" data-masonry="{&quot;percentPosition&quot;: true }" style="position: relative; height: 408.5px;">
			<div class="item features-without-image col-12 col-md-6 col-lg-4 active hidden animate__animated animate__delay-1s" style="position: absolute; left: 0%; top: 0px;">
				<div class="item-wrapper">
					<div class="card-box align-left">
						<p class="card-text mbr-fonts-style display-7">
							J'adore ma bague écologique, c'est un bijou unique et éthique!
						</p>
						<div class="img-wrapper mt-4 mb-3">
							<img src="images/index_033.jpeg" data-slide-to="0" data-bs-slide-to="0">
						</div>
						<h5 class="card-title mbr-fonts-style display-7">
							<strong>Sophie Martin</strong>
						</h5>
					</div>
				</div>
			</div>
			<div class="item features-without-image col-12 col-md-6 col-lg-4 hidden animate__animated animate__delay-1s" style="position: absolute; left: 33.3333%; top: 0px;">
				<div class="item-wrapper">
					<div class="card-box align-left">
						<p class="card-text mbr-fonts-style display-7">
							Les bijoux recyclés sont magnifiques, et je suis fier de soutenir cette initiative!
						</p>
						<div class="img-wrapper mt-4 mb-3">
							<img src="images/index_003.jpeg" data-slide-to="1" data-bs-slide-to="1">
						</div>
						<h5 class="card-title mbr-fonts-style display-7">
							<strong>Lucas Dubois</strong>
						</h5>
					</div>
				</div>
			</div>
			<div class="item features-without-image col-12 col-md-6 col-lg-4 hidden animate__animated animate__delay-1s" style="position: absolute; left: 66.6667%; top: 0px;">
				<div class="item-wrapper">
					<div class="card-box align-left">
						<p class="card-text mbr-fonts-style display-7">
							C'est incroyable de voir comment ces bijoux contribuent à des causes importantes.
						</p>
						<div class="img-wrapper mt-4 mb-3">
							<img src="images/index_016.jpeg" data-slide-to="2" data-bs-slide-to="2">
						</div>
						<h5 class="card-title mbr-fonts-style display-7">
							<strong>Camille Lefevre</strong>
						</h5>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
    <style>
  .cid-u6fkJMTUk7 {
    padding-top: 6rem;
    padding-bottom: 6rem;
    background-color: #ffffff;
  }
  .cid-u6fkJMTUk7 .item-subtitle {
    line-height: 1.2;
    color: #000000;
  }
  .cid-u6fkJMTUk7 img,
  .cid-u6fkJMTUk7 .item-img {
    width: 100%;
    height: 100%;
    height: 400px;
    object-fit: cover;
  }
  .cid-u6fkJMTUk7 .item:focus,
  .cid-u6fkJMTUk7 span:focus {
    outline: none;
  }
  .cid-u6fkJMTUk7 .item {
    margin-bottom: 2rem;
  }
  @media (max-width: 767px) {
    .cid-u6fkJMTUk7 .item {
      margin-bottom: 1rem;
    }
  }
  .cid-u6fkJMTUk7 .item-wrapper {
    position: relative;
    border-radius: 4px;
    height: 100%;
    display: flex;
    flex-flow: column nowrap;
  }
  .cid-u6fkJMTUk7 .mbr-section-title {
    color: #232323;
  }
  .cid-u6fkJMTUk7 .mbr-text,
  .cid-u6fkJMTUk7 .mbr-section-btn {
    color: #232323;
  }
  .cid-u6fkJMTUk7 .item-title {
    color: #232323;
  }
  .cid-u6fkJMTUk7 .content-head {
    max-width: 800px;
  }
</style>
<section class="features03 cid-u6fkJMTUk7" id="events-1-u6fkJMTUk7">
	<div class="container-fluid">
		<div class="row justify-content-center mb-5">
			<div class="col-12 content-head">
				<div class="mbr-section-head">
					<h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2 hidden animate__animated animate__delay-1s">
						<strong>Événements à Venir</strong>
					</h4>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="item features-image col-12 col-md-6 col-lg-3 active hidden animate__animated animate__delay-1s">
				<div class="item-wrapper">
					<div class="item-img mb-3">
						<img src="images/index_026.jpeg">
					</div>
					<div class="item-content align-left">
						<h6 class="item-subtitle mbr-fonts-style mb-3 display-5">
							<strong><a class="text-black fw-bold" href="#">Atelier de Recyclage Créatif</a></strong>
						</h6>
						<p class="mbr-text mbr-fonts-style mb-3 display-7">Samedi 10 Février</p>
						<p class="mbr-text mbr-fonts-style mb-3 display-7">Rejoignez-nous pour un atelier de création de bijoux recyclés et découvrez l'art du recyclage créatif.</p>
						<div class="mbr-section-btn item-footer"><a href="#" class="btn item-btn btn-primary display-7">Participer</a></div>
					</div>
				</div>
			</div>
			<div class="item features-image col-12 col-md-6 col-lg-3 hidden animate__animated animate__delay-1s">
				<div class="item-wrapper">
					<div class="item-img mb-3">
						<img src="images/index_036.jpeg" data-slide-to="1" data-bs-slide-to="1">
					</div>
					<div class="item-content align-left">
						<h6 class="item-subtitle mbr-fonts-style mb-3 display-5">
							<strong><a class="text-black fw-bold" href="#">Vente de Bienfaisance Écologique</a></strong>
						</h6>
						<p class="mbr-text mbr-fonts-style mb-3 display-7">Dimanche 18 Février</p>
						<p class="mbr-text mbr-fonts-style mb-3 display-7">Ne manquez pas notre vente de bijoux écologiques au profit des associations environnementales.</p>
						<div class="mbr-section-btn item-footer"><a href="#" class="btn item-btn btn-primary display-7">Participer</a></div>
					</div>
				</div>
			</div>
			<div class="item features-image col-12 col-md-6 col-lg-3 hidden animate__animated animate__delay-1s">
				<div class="item-wrapper">
					<div class="item-img mb-3">
						<img src="images/index_018.jpeg" data-slide-to="2" data-bs-slide-to="2">
					</div>
					<div class="item-content align-left">
						<h6 class="item-subtitle mbr-fonts-style mt-0 mb-3 display-5">
							<strong><a class="text-black fw-bold" href="#">Conférence sur le Recyclage Éthique</a></strong>
						</h6>
						<p class="mbr-text mbr-fonts-style mb-3 display-7">Samedi 24 Février</p>
						<p class="mbr-text mbr-fonts-style mb-3 display-7">Assistez à notre conférence sur l'importance du recyclage éthique dans l'industrie de la mode et des bijoux.</p>
						<div class="mbr-section-btn item-footer"><a href="#" class="btn item-btn btn-primary display-7">Participer</a></div>
					</div>
				</div>
			</div>
			<div class="item features-image col-12 col-md-6 col-lg-3 hidden animate__animated animate__delay-1s">
				<div class="item-wrapper">
					<div class="item-img mb-3">
						<img src="images/index_034.jpeg" data-slide-to="3" data-bs-slide-to="3">
					</div>
					<div class="item-content align-left">
						<h6 class="item-subtitle mbr-fonts-style mt-0 mb-3 display-5">
							<strong><a class="text-black fw-bold" href="#">Journée de Sensibilisation Écologique</a></strong>
						</h6>
						<p class="mbr-text mbr-fonts-style mb-3 display-7">Dimanche 4 Mars</p>
						<p class="mbr-text mbr-fonts-style mb-3 display-7">Participez à notre journée de sensibilisation pour promouvoir un mode de vie écologique et responsable.</p>
						<div class="mbr-section-btn item-footer"><a href="#" class="btn item-btn btn-primary display-7">Participer</a></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
    <style>
    .cid-u6fkJMTy1c {
        padding-top: 5rem;
        padding-bottom: 3rem;
        background-color: #ffffff;
    }

    .cid-u6fkJMTy1c .item-subtitle {
        line-height: 1.2;
        color: #000000;
    }

    .cid-u6fkJMTy1c img,
    .cid-u6fkJMTy1c .item-img {
        width: 100%;
        height: 100%;
        height: 300px;
        object-fit: cover;
    }

    .cid-u6fkJMTy1c .item:focus,
    .cid-u6fkJMTy1c span:focus {
        outline: none;
    }

    .cid-u6fkJMTy1c .item {
        margin-bottom: 2rem;
    }

    @media (max-width: 767px) {
        .cid-u6fkJMTy1c .item {
            margin-bottom: 1rem;
        }
    }

    .cid-u6fkJMTy1c .item-wrapper {
        position: relative;
        border-radius: 4px;
        height: 100%;
        display: flex;
        flex-flow: column nowrap;
    }

    .cid-u6fkJMTy1c .mbr-section-title {
        color: #000000;
    }

    .cid-u6fkJMTy1c .mbr-text,
    .cid-u6fkJMTy1c .mbr-section-btn {
        color: #000000;
    }

    .cid-u6fkJMTy1c .item-title {
        color: #000000;
    }

    .cid-u6fkJMTy1c .content-head {
        max-width: 800px;
    }
</style>
<section class="blog-2 cid-u6fkJMTy1c" id="blog-2-u6fkJMTy1c">
    <div class="container-fluid">
        <div class="row justify-content-center mb-5">
            <div class="col-12 content-head">
                <div class="mbr-section-head">
                    <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2 hidden animate__animated animate__delay-1s">
                        <strong>Bijoux Recyclés</strong>
                    </h4>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="item features-image col-12 col-md-6 col-lg-3 active hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img mb-3">
                        <img src="images/index_006.jpeg">
                    </div>
                    <div class="item-content align-left">
                        <h5 class="item-title mbr-fonts-style mt-0 mb-3 display-7">
                            Tendance
                        </h5>
                        <h6 class="item-subtitle mbr-fonts-style mb-3 display-5">
                            <strong>La Révolution du Recyclage</strong>
                        </h6>

                        <div class="mbr-section-btn item-footer">
                            <a href="" class="btn item-btn btn-primary display-7">
                                Rejoignez
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-lg-3 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img mb-3">
                        <img src="images/index_007.jpeg" data-slide-to="1" data-bs-slide-to="1">
                    </div>
                    <div class="item-content align-left">
                        <h5 class="item-title mbr-fonts-style mb-3 mt-0 display-7">
                            Inspirant
                        </h5>
                        <h6 class="item-subtitle mbr-fonts-style mb-3 display-5">
                            <strong>Histoires de Succès</strong>
                        </h6>
                        <div class="mbr-section-btn item-footer">
                            <a href="" class="btn item-btn btn-primary display-7">
                                Rejoignez
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-lg-3 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img mb-3">
                        <img src="images/index.jpeg" data-slide-to="2" data-bs-slide-to="2">
                    </div>
                    <div class="item-content align-left">
                        <h5 class="item-title mbr-fonts-style mb-3 mt-0 display-7">
                            Éthique
                        </h5>
                        <h6 class="item-subtitle mbr-fonts-style mt-0 mb-3 display-5">
                            <strong>Mode Durable</strong>
                        </h6>
                        <div class="mbr-section-btn item-footer">
                            <a href="" class="btn item-btn btn-primary display-7">
                                Rejoignez
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item features-image col-12 col-md-6 col-lg-3 hidden animate__animated animate__delay-1s">
                <div class="item-wrapper">
                    <div class="item-img mb-3">
                        <img src="images/index_005.jpeg" data-slide-to="3" data-bs-slide-to="4">
                    </div>
                    <div class="item-content align-left">
                        <h5 class="item-title mbr-fonts-style mb-3 mt-0 display-7">
                            Créatif
                        </h5>
                        <h6 class="item-subtitle mbr-fonts-style mt-0 mb-3 display-5">
                            <strong>
                                Artisanat Innovant
                            </strong>
                        </h6>

                        <div class="mbr-section-btn item-footer">
                            <a href="" class="btn item-btn btn-primary display-7">
                                Rejoignez
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    <style>
  .cid-u6fkJMTYqA {
    padding-top: 5rem;
    padding-bottom: 5rem;
    background-color: var(--dominant-color, #260a30);
  }

  .cid-u6fkJMTYqA input {
    padding: 1.2rem 1.5rem;
    border: none !important;
    height: 100%;
  }

  .cid-u6fkJMTYqA input:hover {
    border: none !important;
  }

  .cid-u6fkJMTYqA .btn {
    height: 100%;
    margin: auto;
  }

  @media (min-width: 992px) {
    .cid-u6fkJMTYqA .text-wrapper {
      padding: 0 2rem;
    }
  }

  .cid-u6fkJMTYqA .row {
    justify-content: center;
  }

  .cid-u6fkJMTYqA .mbr-section-btn {
    display: flex;
    margin-bottom: 1.2rem;
    width: fit-content;
  }

  @media (min-width: 768px) {
    .cid-u6fkJMTYqA .mbr-section-btn {
      margin-left: initial;
    }
  }

  .cid-u6fkJMTYqA .mbr-section-btn .btn {
    width: auto;
  }

  @media (max-width: 991px) {
    .cid-u6fkJMTYqA .image-wrapper {
      margin-bottom: 2rem;
    }

    .cid-u6fkJMTYqA .content-wrapper {
      flex-direction: column-reverse;
    }
  }

  .cid-u6fkJMTYqA .justify-content-center {
    align-items: center;
  }

  .cid-u6fkJMTYqA .mbr-section-title {
    text-align: center;
    color: var(--dominant-text, #ffd7ef);
  }
</style>
<section class="header2 cid-u6fkJMTYqA" id="subscription-form-1-u6fkJMTYqA">
  <div class="container">
    <div class="row content-wrapper justify-content-center">
      <div class="col-lg-8 mbr-form">
        <div class="">
          <h1 class="mbr-section-title mbr-fonts-style mb-5 display-1 hidden animate__animated animate__delay-1s">
            <strong>Soyez Partie de la Révolution</strong>
          </h1>
        </div>
        <div class="text-wrapper align-left" data-form-type="formoid">
          <form action="https://mobirise.eu/" method="POST" class="mbr-form form-with-styler" data-form-title="Form Name"><input type="hidden" name="email" data-form-email="true" value="">
            <div class="row">
              <div data-form-alert="" class="alert alert-success col-12" hidden="hidden">Thanks for filling out the form!</div>
              <div data-form-alert-danger="" class="alert alert-danger col-12" hidden="hidden">
                Oops...! some problem!
              </div>
            </div>
            <div class="dragArea row">
              <div data-for="email" class="col-lg-6 col-md-6 col-sm-12 form-group">
                <input type="email" name="email" placeholder="test@email.com" data-form-field="email" class="form-control display-7" id="email-header02-0">
              </div>
              <div class="col-auto mbr-section-btn"><button type="submit" class="w-100 btn btn-primary display-7">S'inscrire</button></div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
    <style>
  .cid-u6fkJMT3sb {
    padding-top: 6rem;
    padding-bottom: 6rem;
    background: transparent;
  }
  .cid-u6fkJMT3sb .mbr-fallback-image.disabled {
    display: none;
  }
  .cid-u6fkJMT3sb .mbr-fallback-image {
    display: block;
    background-size: cover;
    background-position: center center;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
  }
  @media (min-width: 768px) {
    .cid-u6fkJMT3sb .container-fluid {
      padding: 0;
    }
  }
  .cid-u6fkJMT3sb .embla__slide {
    display: flex;
    justify-content: center;
    position: relative;
    min-width: 490px;
    max-width: 490px;
  }
  @media (max-width: 768px) {
    .cid-u6fkJMT3sb .embla__slide {
      min-width: 100%;
      max-width: 100%;
      margin-left: 1rem !important;
      margin-right: 1rem !important;
    }
  }
  .cid-u6fkJMT3sb .embla__slide a {
    display: block;
    width: 100%;
  }
  .cid-u6fkJMT3sb .embla__button--next,
  .cid-u6fkJMT3sb .embla__button--prev {
    display: flex;
  }
  .cid-u6fkJMT3sb .mobi-mbri-arrow-next {
    margin-left: 5px;
  }
  .cid-u6fkJMT3sb .mobi-mbri-arrow-prev {
    margin-right: 5px;
  }
  .cid-u6fkJMT3sb .embla__button {
    top: 50%;
    width: 60px;
    height: 60px;
    margin-top: -1.5rem;
    font-size: 22px;
    border: 2px solid #fff;
    border-radius: 50%;
    transition: all 0.3s;
    position: absolute;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .cid-u6fkJMT3sb .embla__button:disabled {
    cursor: default;
    display: none;
  }
  .cid-u6fkJMT3sb .embla__button.embla__button--prev {
    left: 0;
    margin-left: 2.5rem;
  }
  .cid-u6fkJMT3sb .embla__button.embla__button--next {
    right: 0;
    margin-right: 2.5rem;
  }
  @media (max-width: 767px) {
    .cid-u6fkJMT3sb .embla__button {
      top: auto;
      bottom: 1rem;
    }
  }
  .cid-u6fkJMT3sb .embla {
    position: relative;
    width: 100%;
  }
  .cid-u6fkJMT3sb .embla__viewport {
    overflow: hidden;
    width: 100%;
  }
  .cid-u6fkJMT3sb .embla__viewport.is-draggable {
    cursor: grab;
  }
  .cid-u6fkJMT3sb .embla__viewport.is-dragging {
    cursor: grabbing;
  }
  .cid-u6fkJMT3sb .embla__slide a {
    cursor: grab;
  }
  .cid-u6fkJMT3sb .embla__slide a:active {
    cursor: grabbing;
  }
  .cid-u6fkJMT3sb .embla__container {
    display: flex;
    user-select: none;
    -webkit-touch-callout: none;
    -khtml-user-select: none;
    -webkit-tap-highlight-color: transparent;
  }
  .cid-u6fkJMT3sb .item-menu-overlay {
    border-radius: 2rem;
  }
  .cid-u6fkJMT3sb .mbr-section-title {
    color: #232323;
  }
  .cid-u6fkJMT3sb .mbr-section-subtitle {
    color: #232323;
  }
  .cid-u6fkJMT3sb .mbr-box {
    color: #ffffff;
  }
  .cid-u6fkJMT3sb .slide-content {
    position: relative;
    border-radius: 4px;
    height: 100%;
    display: flex;
    overflow: hidden;
    flex-flow: column nowrap;
  }
  .cid-u6fkJMT3sb img,
  .cid-u6fkJMT3sb .item-img {
    width: 100%;
    height: 400px;
    object-fit: cover;
  }
  .cid-u6fkJMT3sb .item-wrapper {
    position: relative;
  }
  .cid-u6fkJMT3sb .content-head {
    max-width: 800px;
  }
</style>
<section class="slider4 mbr-embla cid-u6fkJMT3sb" id="gallery-5-u6fkJMT3sb">
  <div class="container-fluid">
    <div class="row mb-5 justify-content-center">
      <div class="col-12 content-head">
        <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2 hidden animate__animated animate__delay-1s">
          <strong>Bijoux en Action</strong>
        </h3>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="embla position-relative" data-skip-snaps="true" data-align="center" data-contain-scroll="trimSnaps" data-loop="true" data-auto-play="true" data-auto-play-interval="2" data-draggable="true">
          <div class="embla__viewport is-draggable">
            <div class="embla__container" style="transform: translate3d(-17.9688%, 0px, 0px);">
              <div class="embla__slide slider-image item is-selected hidden animate__animated animate__delay-1s" style="margin-left: 1rem; margin-right: 1rem; left: 0%;">
                <div class="slide-content">
                  <div class="item-img">
                    <div class="item-wrapper">
                      <img src="images/index_013.jpeg">
                    </div>
                  </div>
                </div>
              </div>
              <div class="embla__slide slider-image item is-selected hidden animate__animated animate__delay-1s" style="margin-left: 1rem; margin-right: 1rem; left: 0%;">
                <div class="slide-content">
                  <div class="item-img">
                    <div class="item-wrapper">
                      <img src="images/index_020.jpeg">
                    </div>
                  </div>
                </div>
              </div>
              <div class="embla__slide slider-image item is-selected hidden animate__animated animate__delay-1s" style="margin-left: 1rem; margin-right: 1rem; left: 0%;">
                <div class="slide-content">
                  <div class="item-img">
                    <div class="item-wrapper">
                      <img src="images/index_017.jpeg">
                    </div>
                  </div>
                </div>
              </div>
              <div class="embla__slide slider-image item is-selected hidden animate__animated animate__delay-1s" style="margin-left: 1rem; margin-right: 1rem; left: 0%;">
                <div class="slide-content">
                  <div class="item-img">
                    <div class="item-wrapper">
                      <img src="images/index_015.jpeg">
                    </div>
                  </div>
                </div>
              </div>
              <div class="embla__slide slider-image item is-selected hidden animate__animated animate__delay-1s" style="margin-left: 1rem; margin-right: 1rem; left: 0%;">
                <div class="slide-content">
                  <div class="item-img">
                    <div class="item-wrapper">
                      <img src="images/index_027.jpeg">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <button class="embla__button embla__button--prev hidden animate__animated animate__delay-1s">
            <span class="mobi-mbri mobi-mbri-arrow-prev" aria-hidden="true"></span>
            <span class="sr-only visually-hidden visually-hidden">Previous</span>
          </button>
          <button class="embla__button embla__button--next hidden animate__animated animate__delay-1s">
            <span class="mobi-mbri mobi-mbri-arrow-next" aria-hidden="true"></span>
            <span class="sr-only visually-hidden visually-hidden">Next</span>
          </button>
        </div>
      </div>
    </div>
  </div>
</section>
    <style>
  .cid-u6fkJMUUsc {
    padding-top: 5rem;
    padding-bottom: 5rem;
    background-color: transparent;
  }
  .cid-u6fkJMUUsc .mbr-iconfont {
    font-size: 1.2rem !important;
    font-family: 'Moririse2' !important;
    color: white;
    transition: all 0.3s;
    transform: rotate(180deg);
  }
  .cid-u6fkJMUUsc .panel-group {
    border: none;
  }
  .cid-u6fkJMUUsc .card-header {
    padding: 1.2rem 0.5rem;
  }
  @media (max-width: 767px) {
    .cid-u6fkJMUUsc .card-header {
      padding: 1rem 0rem;
    }
  }
  .cid-u6fkJMUUsc .panel-body {
    padding: 0 0.5rem;
    padding-bottom: 1rem;
  }
  @media (max-width: 767px) {
    .cid-u6fkJMUUsc .panel-body {
      padding: 0rem;
      padding-bottom: 1rem;
    }
  }
  .cid-u6fkJMUUsc .img-col {
    padding: 0;
  }
  .cid-u6fkJMUUsc .img-item {
    height: 100%;
  }
  .cid-u6fkJMUUsc img {
    height: 100%;
    object-fit: cover;
  }
  .cid-u6fkJMUUsc .collapsed span {
    transform: rotate(0deg);
  }
  .cid-u6fkJMUUsc .panel-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .cid-u6fkJMUUsc p {
    margin-bottom: 0.3rem;
  }
  .cid-u6fkJMUUsc .card .card-header {
    background-color: transparent;
    margin-bottom: 0;
    border: 0;
    border-radius: 2rem;
  }
  .cid-u6fkJMUUsc .card {
    background: #ffffff;
    padding: 1rem 2rem;
    border-radius: 2rem;
  }
  @media (max-width: 767px) {
    .cid-u6fkJMUUsc .card {
      padding: 1.5rem;
    }
  }
  .cid-u6fkJMUUsc .panel-text {
    color: #000000;
  }
  .cid-u6fkJMUUsc .mbr-section-title {
    text-align: center;
    color: #000000;
  }
  .cid-u6fkJMUUsc .mbr-section-subtitle {
    color: #000000;
    text-align: center;
  }
  .cid-u6fkJMUUsc .panel-title-edit,
  .cid-u6fkJMUUsc .mbr-iconfont {
    color: #000000;
  }
</style>
<section class="list1 cid-u6fkJMUUsc" id="faq-1-u6fkJMUUsc">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-12 col-md-12 col-lg-10 m-auto">
				<div class="content">
					<div class="mbr-section-head align-left mb-5">
						<h3 class="mbr-section-title mb-2 mbr-fonts-style display-2 hidden animate__animated animate__delay-1s">
							<strong>Questions Fréquentes</strong>
						</h3>
					</div>
					<div id="bootstrap-accordion_0" class="panel-group accordionStyles accordion" role="tablist" aria-multiselectable="true">
						<div class="card mb-3">
							<div class="card-header" role="tab" id="headingOne">
								<a role="button" class="panel-title collapsed" data-toggle="collapse" data-bs-toggle="collapse" data-core="" href="#collapse1_0" aria-expanded="false" aria-controls="collapse1">
									<h6 class="panel-title-edit mbr-semibold mbr-fonts-style mb-0 display-5">
										Que faites-vous des bijoux recyclés ?
									</h6>
									<span class="sign mbr-iconfont mobi-mbri-arrow-down"></span>
								</a>
							</div>
							<div id="collapse1_0" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion" data-bs-parent="#bootstrap-accordion_0">
								<div class="panel-body">
									<p class="mbr-fonts-style panel-text display-7">
										Nous les vendons pour soutenir des associations.
									</p>
								</div>
							</div>
						</div>
						<div class="card mb-3">
							<div class="card-header" role="tab" id="headingOne">
								<a role="button" class="panel-title collapsed" data-toggle="collapse" data-bs-toggle="collapse" data-core="" href="#collapse2_0" aria-expanded="false" aria-controls="collapse2">
									<h6 class="panel-title-edit mbr-semibold mbr-fonts-style mb-0 display-5">
										Comment puis-je contribuer ?
									</h6>
									<span class="sign mbr-iconfont mobi-mbri-arrow-down"></span>
								</a>
							</div>
							<div id="collapse2_0" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion" data-bs-parent="#bootstrap-accordion_0">
								<div class="panel-body">
									<p class="mbr-fonts-style panel-text display-7">
										Envoyez-nous vos bijoux recyclés !
									</p>
								</div>
							</div>
						</div>
						<div class="card mb-3">
							<div class="card-header" role="tab" id="headingOne">
								<a role="button" class="panel-title collapsed" data-toggle="collapse" data-bs-toggle="collapse" data-core="" href="#collapse3_0" aria-expanded="false" aria-controls="collapse3">
									<h6 class="panel-title-edit mbr-semibold mbr-fonts-style mb-0 display-5">
										Quels types de bijoux acceptez-vous ?
									</h6>
									<span class="sign mbr-iconfont mobi-mbri-arrow-down"></span>
								</a>
							</div>
							<div id="collapse3_0" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion" data-bs-parent="#bootstrap-accordion_0">
								<div class="panel-body">
									<p class="mbr-fonts-style panel-text display-7">
										Tous les types de bijoux sont les bienvenus !
									</p>
								</div>
							</div>
						</div>
						<div class="card mb-3">
							<div class="card-header" role="tab" id="headingOne">
								<a role="button" class="panel-title collapsed" data-toggle="collapse" data-bs-toggle="collapse" data-core="" href="#collapse4_0" aria-expanded="false" aria-controls="collapse4">
									<h6 class="panel-title-edit mbr-semibold mbr-fonts-style mb-0 display-5">
										Comment puis-je acheter des bijoux recyclés ?
									</h6>
									<span class="sign mbr-iconfont mobi-mbri-arrow-down"></span>
								</a>
							</div>
							<div id="collapse4_0" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion" data-bs-parent="#bootstrap-accordion_0">
								<div class="panel-body">
									<p class="mbr-fonts-style panel-text display-7">
										Visitez notre boutique en ligne !
									</p>
								</div>
							</div>
						</div>
						<div class="card mb-3">
							<div class="card-header" role="tab" id="headingOne">
								<a role="button" class="panel-title collapsed" data-toggle="collapse" data-bs-toggle="collapse" data-core="" href="#collapse5_0" aria-expanded="false" aria-controls="collapse5">
									<h6 class="panel-title-edit mbr-semibold mbr-fonts-style mb-0 display-5">
										Puis-je faire des dons en nature ?
									</h6>
									<span class="sign mbr-iconfont mobi-mbri-arrow-down"></span>
								</a>
							</div>
							<div id="collapse5_0" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion" data-bs-parent="#bootstrap-accordion_0">
								<div class="panel-body">
									<p class="mbr-fonts-style panel-text display-7">
										Oui, contactez-nous pour plus d'informations.
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
    <style>
.cid-u6fkJMUL8s {
  padding-top: 6rem;
  padding-bottom: 6rem;
  background-color: #ffffff;
}
.cid-u6fkJMUL8s .item:focus,
.cid-u6fkJMUL8s span:focus {
  outline: none;
}
.cid-u6fkJMUL8s .container-fluid {
  padding-left: 0;
  padding-right: 0;
  overflow: hidden;
}
.cid-u6fkJMUL8s .content-head {
  max-width: 800px;
}
.cid-u6fkJMUL8s .item {
  color: #232323;
  min-height: 90px;
  font-weight: bold;
}
@media (max-width: 768px) {
  .cid-u6fkJMUL8s .item {
    min-height: 45px;
  }
}
</style>
<section class="gallery10 cid-u6fkJMUL8s" id="features-61-u6fkJMUL8s">
  <div class="container-fluid">
      <div class="loop-container" style="position: relative; display: inline-flex; white-space: nowrap; transform: translateX(-1.4%);">
        <div class="item display-1 hidden animate__animated animate__delay-1s" data-linewords="
          Innovant *
          Écologique *
          Engagé *
          Créatif *
          Solidaire *
          Inspirant *" data-direction="-1" data-speed="0.05">
          Innovant *
          Écologique *
          Engagé *
          Créatif *
          Solidaire *
          Inspirant *&nbsp;</div>
        <div class="item display-1 hidden animate__animated animate__delay-1s" data-linewords="
          Innovant *
          Écologique *
          Engagé *
          Créatif *
          Solidaire *
          Inspirant *" data-direction="-1" data-speed="0.05" style="position: absolute; left: 100%;">
          Innovant *
          Écologique *
          Engagé *
          Créatif *
          Solidaire *
          Inspirant *&nbsp;</div>
      </div>   
  </div>
</section>
    <style>
.cid-u6fkJMUmil {
  padding-top: 6rem;
  padding-bottom: 6rem;
  background-color: #ffffff;
}
.cid-u6fkJMUmil .item:focus,
.cid-u6fkJMUmil span:focus {
  outline: none;
}
.cid-u6fkJMUmil .item {
  cursor: pointer;
}
.cid-u6fkJMUmil .grid-container {
  grid-row-gap: 2rem;
}
@media (max-width: 767px) {
  .cid-u6fkJMUmil .grid-container {
    grid-row-gap: 1rem;
  }
}
.cid-u6fkJMUmil .grid-container-1,
.cid-u6fkJMUmil .grid-container-2,
.cid-u6fkJMUmil .grid-container-3 {
  gap: 0 2rem;
}
@media (max-width: 767px) {
  .cid-u6fkJMUmil .grid-container-1,
  .cid-u6fkJMUmil .grid-container-2,
  .cid-u6fkJMUmil .grid-container-3 {
    gap: 0 1rem;
  }
}
.cid-u6fkJMUmil .mbr-section-title {
  color: #000000;
}
.cid-u6fkJMUmil .mbr-text,
.cid-u6fkJMUmil .mbr-section-btn {
  color: #000000;
}
.cid-u6fkJMUmil .content-head {
  max-width: 800px;
}
.cid-u6fkJMUmil .container,
.cid-u6fkJMUmil .container-fluid {
  overflow: hidden;
}
.cid-u6fkJMUmil .grid-container {
  display: grid;
  transform: translate3d(-3rem, 0, 0);
  width: 115vw;
  grid-column-gap: 1rem;
}
.cid-u6fkJMUmil .grid-item {
  display: flex;
  justify-content: center;
  align-items: center;
}
.cid-u6fkJMUmil .grid-item img {
  min-width: 30vw;
  max-width: 100%;
  max-height: 100%;
  object-fit: cover;
}
@media (max-width: 767px) {
  .cid-u6fkJMUmil .grid-item img {
    min-width: 35vw;
  }
}
.cid-u6fkJMUmil .grid-container-1,
.cid-u6fkJMUmil .grid-container-2,
.cid-u6fkJMUmil .grid-container-3 {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-auto-columns: 1fr;
  grid-auto-flow: column;
}
.cid-u6fkJMUmil .grid-container-1 {
  align-items: flex-end;
}
.cid-u6fkJMUmil .grid-container-2 {
  align-items: flex-start;
}
</style>
<section class="gallery07 cid-u6fkJMUmil" id="gallery-16-u6fkJMUmil">
  <div class="container-fluid gallery-wrapper">
    <div class="row justify-content-center">
      <div class="col-12 content-head">
        <div class="mbr-section-head mb-5">
          <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2 hidden animate__animated animate__delay-1s">
            <strong>Bijoux Recyclés</strong>
          </h4>
        </div>
      </div>
    </div>
    <div class="grid-container">
      <div class="grid-container-3" style="transform: translate3d(-200px, 0px, 0px);">
        <div class="grid-item">
          <img src="images/index_002.jpeg" class="hidden animate__animated animate__delay-1s">
        </div>
        <div class="grid-item">
          <img src="images/index_014.jpeg" class="hidden animate__animated animate__delay-1s">
        </div>
        <div class="grid-item">
          <img src="images/index_029.jpeg" class="hidden animate__animated animate__delay-1s">
        </div>
        <div class="grid-item">
          <img src="images/index_035.jpeg" class="hidden animate__animated animate__delay-1s">
        </div>
      </div>
    </div>
  </div>
</section>
    <style>
.cid-u6fkJMU5zP {
  padding-top: 5rem;
  padding-bottom: 5rem;
  background-color: #ffffff;
}
.cid-u6fkJMU5zP .mbr-fallback-image.disabled {
  display: none;
}
.cid-u6fkJMU5zP .mbr-fallback-image {
  display: block;
  background-size: cover;
  background-position: center center;
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
}
.cid-u6fkJMU5zP .bg-facebook {
  background: #1778f2;
  color: #ffffff;
}
.cid-u6fkJMU5zP .bg-facebook:hover {
  background: #0b60cb;
}
.cid-u6fkJMU5zP .bg-twitter {
  background: #1da1f2;
  color: #ffffff;
}
.cid-u6fkJMU5zP .bg-twitter:hover {
  background: #0c85d0;
}
.cid-u6fkJMU5zP .bg-instagram {
  background: #f00075;
  color: #ffffff;
}
.cid-u6fkJMU5zP .bg-instagram:hover {
  background: #bd005c;
}
.cid-u6fkJMU5zP .bg-tiktok {
  background: #000000;
  color: #ffffff;
}
.cid-u6fkJMU5zP .bg-tiktok:hover {
  background: #000000;
}
.cid-u6fkJMU5zP .iconfont-wrapper {
  display: inline-block;
  font-size: 32px;
  border-radius: 50%;
  width: 72px;
  height: 72px;
  line-height: 72px;
  text-align: center;
  transition: all 0.3s ease-in-out;
}
.cid-u6fkJMU5zP [class^="socicon-"]:before,
.cid-u6fkJMU5zP [class*=" socicon-"]:before {
  line-height: 55px;
  padding: .6rem;
}

</style>
<section class="social4 cid-u6fkJMU5zP" id="follow-us-1-u6fkJMU5zP">
    <div class="container">
        <div class="media-container-row">
            <div class="col-12">
                <h3 class="mbr-section-title align-center mb-5 mbr-fonts-style display-2 hidden animate__animated animate__delay-1s">
                    <strong>Suivez-nous</strong>
                </h3>
                <div class="social-list align-center">
                    <a class="iconfont-wrapper bg-facebook m-2 hidden animate__animated animate__delay-1s" target="_blank" href="#">
                        <span class="socicon-facebook socicon"></span>
                    </a>
                    <a class="iconfont-wrapper bg-twitter m-2 hidden animate__animated animate__delay-1s" href="#" target="_blank">
                        <span class="socicon-twitter socicon"></span>
                    </a>
                    <a class="iconfont-wrapper bg-instagram m-2 hidden animate__animated animate__delay-1s" href="#" target="_blank">
                        <span class="socicon-instagram socicon"></span>
                    </a>
                    <a class="iconfont-wrapper bg-tiktok m-2 hidden animate__animated animate__delay-1s" href="#" target="_blank">
                        <span class="socicon-tiktok socicon"></span>
                    </a>                   
                </div>
            </div>
        </div>
    </div>
</section>
    <style>
.cid-u6fkJMUIDp {
  padding-top: 6rem;
  padding-bottom: 6rem;
  background-color: transparent;
}
.cid-u6fkJMUIDp .mbr-overlay {
  background-color: #ffffff;
  opacity: 0.4;
}
.cid-u6fkJMUIDp form .mbr-section-btn {
  text-align: center;
  width: 100%;
}
.cid-u6fkJMUIDp form .mbr-section-btn .btn {
  display: inline-flex;
}
@media (max-width: 991px) {
  .cid-u6fkJMUIDp form .mbr-section-btn .btn {
    width: 100%;
  }
}
.cid-u6fkJMUIDp .content-head {
  max-width: 800px;
}

</style>
<section class="form5 cid-u6fkJMUIDp" id="contact-form-3-u6fkJMUIDp">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 content-head">
                <div class="mbr-section-head mb-5">
                    <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2 hidden animate__animated animate__delay-1s">
                        <strong>Contactez-nous</strong>
                    </h3>                    
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-8 mx-auto mbr-form" data-form-type="formoid">
                <form action="https://mobirise.eu/" method="POST" class="mbr-form form-with-styler" data-form-title="Form Name"><input type="hidden" name="email" data-form-email="true" value="">
                    <div class="row">
                        <div data-form-alert="" class="alert alert-success col-12" hidden="hidden">Thanks for filling out the form!</div>
                        <div data-form-alert-danger="" class="alert alert-danger col-12" hidden="hidden">
                            Oops...! some problem!
                        </div>
                    </div>
                    <div class="dragArea row">
                        <div class="col-md col-sm-12 form-group mb-3" data-for="name">
                            <input type="text" name="name" placeholder="Nom" data-form-field="name" class="form-control" id="name-form02-0">
                        </div>
                        <div class="col-md col-sm-12 form-group mb-3" data-for="email">
                            <input type="email" name="email" placeholder="Email" data-form-field="email" class="form-control" id="email-form02-0">
                        </div>
                        <div class="col-12 form-group mb-3" data-for="url">
                            <input type="url" name="url" placeholder="Téléphone" data-form-field="url" class="form-control" id="url-form5-0">
                        </div>
                        <div class="col-12 form-group mb-3" data-for="textarea">
                            <textarea name="textarea" placeholder="Message" data-form-field="textarea" class="form-control" id="textarea-form02-0"></textarea>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 align-center mbr-section-btn"><button type="submit" class="btn btn-primary display-7">Envoyer</button></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
    <style>
.cid-u6fkJMUeOe {
  padding-top: 5rem;
  padding-bottom: 5rem;
  background-color: transparent;
}
.cid-u6fkJMUeOe .mbr-fallback-image.disabled {
  display: none;
}
.cid-u6fkJMUeOe .mbr-fallback-image {
  display: block;
  background-size: cover;
  background-position: center center;
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
}
.cid-u6fkJMUeOe .mbr-text {
  color: #000000;
}
.cid-u6fkJMUeOe .mbr-section-subtitle {
  color: ##000000;
  text-align: left;
}
.cid-u6fkJMUeOe .main-button {
  margin-bottom: 2rem;
}
@media (max-width: 767px) {
  .cid-u6fkJMUeOe .main-button {
    margin-bottom: 2rem;
  }
}
.cid-u6fkJMUeOe .mbr-section-subtitle,
.cid-u6fkJMUeOe .main-button {
  color: #000000;
}
.cid-u6fkJMUeOe .google-map {
  height: 30rem;
  position: relative;
  border-radius: 2rem;
}
.cid-u6fkJMUeOe .google-map iframe {
  height: 100%;
  width: 100%;
  border-radius: 2rem;
}
.cid-u6fkJMUeOe .google-map [data-state-details] {
  color: #6b6763;
  height: 1.5em;
  margin-top: -0.75em;
  padding-left: 1.25rem;
  padding-right: 1.25rem;
  position: absolute;
  text-align: center;
  top: 50%;
  width: 100%;
}
.cid-u6fkJMUeOe .google-map[data-state] {
  background: #e9e5dc;
}
.cid-u6fkJMUeOe .google-map[data-state="loading"] [data-state-details] {
  display: none;
}
</style>

<section class="contacts03 cid-u6fkJMUeOe" id="contacts-11-u6fkJMUeOe">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-4">
        <div class="col-12 col-md-12">
          <h5 class="mbr-section-title mbr-fonts-style mt-0 mb-4 display-2 hidden animate__animated animate__delay-1s">
            <strong>Coordonnées</strong>
          </h5>
          <p class="mbr-section-subtitle mbr-fonts-style mt-0 mb-4 display-7 hidden animate__animated animate__delay-1s">
            Téléphone: <a href="">123-456-7890</a>
            <br>Email: info@bijouxrecycles.com
            <br>Adresse: Paris France
            <br>Heures d'ouverture: Lun - Ven: 9h00 - 17h00</p> 
        </div>
      </div>
      <div class="col-lg-8 side-features">
        <div class="google-map">
          <iframe style="border:0" src="place.html" allowfullscreen="" frameborder="0"></iframe>
        </div>
      </div>
    </div>
  </div>
</section>
    <style>
.cid-u6fkJMURJG {
  padding-top: 5rem;
  padding-bottom: 5rem;
  background-color: #000000;
}
.cid-u6fkJMURJG .social-row {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
}
.cid-u6fkJMURJG .social-row .soc-item {
  margin: 8px;
}
.cid-u6fkJMURJG .social-row .soc-item a:hover .mbr-iconfont,
.cid-u6fkJMURJG .social-row .soc-item a:focus .mbr-iconfont {
  background-color: #ffffff;
}
.cid-u6fkJMURJG .social-row .soc-item a .mbr-iconfont {
  width: 72px;
  height: 72px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 100%;
  font-size: 32px;
  background-color: #edefeb;
  color: #000000;
  transition: all 0.3s ease-in-out;
}
.cid-u6fkJMURJG .row-links {
  width: 100%;
  justify-content: center;
}
.cid-u6fkJMURJG .header-menu {
  list-style: none;
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  padding: 0;
  margin-bottom: 0;
}
.cid-u6fkJMURJG .header-menu li {
  padding: 0 1rem 1rem 1rem;
}
.cid-u6fkJMURJG .header-menu li p {
  margin: 0;
}
.cid-u6fkJMURJG .copyright {
  margin-bottom: 0;
  color: #ffffff;
  text-align: center;
}
.cid-u6fkJMURJG .mbr-section-title {
  color: #ffffff;
}

</style>
<section class="footer3 cid-u6fkJMURJG" once="footers" id="footer-6-u6fkJMURJG">
    <div class="container">
        <div class="row">
            <div class="row-links">
                <ul class="header-menu">
                <li class="header-menu-item mbr-fonts-style display-5 hidden animate__animated animate__delay-1s">
                    <a href="" class="text-white hidden animate__animated animate__delay-1s">Accueil</a>
                  </li><li class="header-menu-item mbr-fonts-style display-5 hidden animate__animated animate__delay-1s">
                    <a href="./inscription/inscription.php" class="text-white hidden animate__animated animate__delay-1s">Inscription</a>
                  </li><li class="header-menu-item mbr-fonts-style display-5 hidden animate__animated animate__delay-1s">
                    <a href="#" class="text-white hidden animate__animated animate__delay-1s">À Propos</a>
                  </li><li class="header-menu-item mbr-fonts-style display-5 hidden animate__animated animate__delay-1s">
                    <a href="#" class="text-white hidden animate__animated animate__delay-1s">Contact</a>
                  </li></ul>
              </div>
            <div class="col-12 mt-4">
                <p class="mbr-fonts-style copyright display-7 hidden animate__animated animate__delay-1s">
                    © 2024 Bijoux Recyclés. Tous droits réservés.
                </p>
            </div>
        </div>
    </div>
</section>

<script src="js/jarallax.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/navbar-dropdown.js"></script>
  <script src="js/masonry.pkgd.min.js"></script>
  <script src="js/imagesloaded.pkgd.min.js"></script>
  <script src="js/embla.min.js"></script>
  <script src="js/script.js"></script>
  <script src="js/mbr-switch-arrow.js"></script>
  <script src="js/scroll-gallery.js"></script>
  <script src="js/smooth-scroll.js"></script>
  <script src="js/index.js"></script>
  <script src="js/script_002.js"></script>
  <script src="js/formoid.min.js"></script>
  
  <script>

    (function(){
      var animationInput = document.createElement('input');
      animationInput.setAttribute('name', 'animation');
      animationInput.setAttribute('type', 'hidden');
      document.body.append(animationInput);
    })();

  </script>

</body></html>